-- 创建医院管理系统数据库
CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- 1. 基础信息表
CREATE TABLE department (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(50) NOT NULL,
    location VARCHAR(100),
    is_inpatient BOOLEAN DEFAULT FALSE  -- 是否为住院科室
);

CREATE TABLE doctor (
    doc_id INT PRIMARY KEY AUTO_INCREMENT,
    doc_name VARCHAR(50) NOT NULL,
    gender CHAR(1) CHECK (gender IN ('男', '女')),
    title VARCHAR(20) NOT NULL,  -- 职称
    dept_id INT NOT NULL,
    phone VARCHAR(20),
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

CREATE TABLE patient (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    gender CHAR(1) CHECK (gender IN ('男', '女')),
    address VARCHAR(200),
    phone VARCHAR(20),
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL
);

CREATE TABLE drug (
    drug_id INT PRIMARY KEY AUTO_INCREMENT,
    drug_name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL,
    usage_instructions TEXT  -- 用法说明
);

-- 2. 门诊部相关表
CREATE TABLE outpatient_schedule (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    doc_id INT NOT NULL,
    schedule_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (doc_id) REFERENCES doctor(doc_id)
);

CREATE TABLE outpatient_visit (
    visit_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doc_id INT NOT NULL,
    visit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_initial_visit BOOLEAN NOT NULL,  -- 是否初诊
    symptom TEXT,
    prescription TEXT,
    diagnosis TEXT,
    fee DECIMAL(10, 2) NOT NULL,
    is_paid BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (patient_id) REFERENCES patient(patient_id),
    FOREIGN KEY (doc_id) REFERENCES doctor(doc_id)
);

-- 3. 住院部相关表
CREATE TABLE ward (
    ward_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_id INT NOT NULL,
    location VARCHAR(100) NOT NULL,
    price_per_day DECIMAL(10, 2) NOT NULL,
    total_beds INT NOT NULL,
    available_beds INT NOT NULL,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

CREATE TABLE inpatient_file (
    file_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doc_id INT NOT NULL,  -- 主治医生
    ward_id INT NOT NULL,
    bed_number INT NOT NULL,
    admit_date DATETIME NOT NULL,
    discharge_date DATETIME,
    initial_diagnosis TEXT,
    deposit DECIMAL(10, 2) NOT NULL,  -- 预缴费
    total_cost DECIMAL(10, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (patient_id) REFERENCES patient(patient_id),
    FOREIGN KEY (doc_id) REFERENCES doctor(doc_id),
    FOREIGN KEY (ward_id) REFERENCES ward(ward_id),
    UNIQUE (ward_id, bed_number)
);

CREATE TABLE inpatient_record (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    file_id INT NOT NULL,
    record_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    symptoms TEXT,
    treatment_plan TEXT,
    prescriptions TEXT,
    daily_cost DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (file_id) REFERENCES inpatient_file(file_id)
);

-- 4. 系统管理表
CREATE TABLE administrator (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(50) NOT NULL,
    role VARCHAR(20) NOT NULL  -- 管理员角色
);