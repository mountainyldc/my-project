-- 插入门诊科室
INSERT INTO department (dept_name, location) VALUES ('内科', '门诊楼3层');
INSERT INTO department (dept_name, location) VALUES ('外科', '门诊楼4层');
-- 插入住院科室
INSERT INTO department (dept_name, location, is_inpatient) VALUES ('妇产科', '住院楼2层', true);
INSERT INTO department (dept_name, location, is_inpatient) VALUES ('肿瘤科', '住院楼3层', true);
-- 内科医生
INSERT INTO doctor (doc_name, gender, title, dept_id, phone, username, password_hash)
VALUES ('张三', '男', '主任医师', 1, '13800000001', 'doctor001', SHA2('password1', 256));
INSERT INTO doctor (doc_name, gender, title, dept_id, phone, username, password_hash)
VALUES ('李四', '女', '副主任医师', 1, '13800000002', 'doctor002', SHA2('password2', 256));

-- 外科医生
INSERT INTO doctor (doc_name, gender, title, dept_id, phone, username, password_hash)
VALUES ('王五', '男', '主治医师', 2, '13800000003', 'doctor003', SHA2('password3', 256));

-- 妇产科医生
INSERT INTO doctor (doc_name, gender, title, dept_id, phone, username, password_hash)
VALUES ('赵六', '女', '主任医师', 3, '13800000004', 'doctor004', SHA2('password4', 256));
INSERT INTO patient (name, gender, address, phone, username, password_hash)
VALUES ('孙七', '男', '北京市朝阳区', '13900000001', 'patient001', SHA2('patientpass1', 256));
INSERT INTO patient (name, gender, address, phone, username, password_hash)
VALUES ('周八', '女', '上海市浦东新区', '13900000002', 'patient002', SHA2('patientpass2', 256));
INSERT INTO drug (drug_name, price, stock, usage_instructions)
VALUES ('感冒灵颗粒', 25.50, 100, '口服，一次1袋，一日3次');
INSERT INTO drug (drug_name, price, stock, usage_instructions)
VALUES ('阿莫西林胶囊', 32.80, 200, '口服，一次2粒，一日3次');
INSERT INTO outpatient_schedule (doc_id, schedule_date, start_time, end_time)
VALUES (1, '2025-06-01', '09:00:00', '11:30:00');
INSERT INTO outpatient_schedule (doc_id, schedule_date, start_time, end_time)
VALUES (2, '2025-06-01', '14:00:00', '16:30:00');
INSERT INTO outpatient_visit (patient_id, doc_id, is_initial_visit, symptom, prescription, diagnosis, fee)
VALUES (1, 1, true, '头痛、发热', '感冒灵颗粒*2盒', '上呼吸道感染', 128.50);
INSERT INTO outpatient_visit (patient_id, doc_id, is_initial_visit, symptom, prescription, diagnosis, fee)
VALUES (2, 2, true, '咳嗽、喉咙痛', '阿莫西林胶囊*1盒', '急性咽炎', 85.00);
INSERT INTO ward (dept_id, location, price_per_day, total_beds, available_beds)
VALUES (3, '住院楼2层A区', 150.00, 10, 10);
INSERT INTO ward (dept_id, location, price_per_day, total_beds, available_beds)
VALUES (4, '住院楼3层B区', 200.00, 8, 8);
INSERT INTO inpatient_file (patient_id, doc_id, ward_id, bed_number, admit_date, initial_diagnosis, deposit)
VALUES (1, 3, 1, 1, '2025-06-01 08:00:00', '肺炎', 2000.00);
INSERT INTO inpatient_record (file_id, symptoms, treatment_plan, prescriptions, daily_cost)
VALUES (1, '咳嗽、发热', '静脉滴注抗生素，吸氧', '头孢曲松钠注射液', 600.00);
INSERT INTO administrator (username, password_hash, name, role)
VALUES ('admin001', SHA2('adminpass1', 256), '系统管理员', '超级管理员');