/*
 Navicat Premium Data Transfer

 Source Server         : 医院
 Source Server Type    : MySQL
 Source Server Version : 80040 (8.0.40)
 Source Host           : localhost:3306
 Source Schema         : hospital_db

 Target Server Type    : MySQL
 Target Server Version : 80040 (8.0.40)
 File Encoding         : 65001

 Date: 26/05/2025 11:54:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for administrator
-- ----------------------------
DROP TABLE IF EXISTS `administrator`;
CREATE TABLE `administrator`  (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`admin_id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of administrator
-- ----------------------------
INSERT INTO `administrator` VALUES (1, 'admin001', 'ebcfc99aa881883fd9a06b78b50b140df65f2794470e444d57470345dacdb536', '系统管理员', '超级管理员');

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dept_id` int NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `is_inpatient` tinyint(1) NULL DEFAULT 0,
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '内科', '门诊楼3层', 0);
INSERT INTO `department` VALUES (2, '外科', '门诊楼4层', 0);
INSERT INTO `department` VALUES (3, '妇产科', '住院楼2层', 1);
INSERT INTO `department` VALUES (4, '肿瘤科', '住院楼3层', 1);

-- ----------------------------
-- Table structure for doctor
-- ----------------------------
DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor`  (
  `doc_id` int NOT NULL AUTO_INCREMENT,
  `doc_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gender` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dept_id` int NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`doc_id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  INDEX `dept_id`(`dept_id` ASC) USING BTREE,
  CONSTRAINT `doctor_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `doctor_chk_1` CHECK (`gender` in (_utf8mb4'男',_utf8mb4'女'))
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of doctor
-- ----------------------------
INSERT INTO `doctor` VALUES (1, '张三', '男', '主任医师', 1, '13800000001', 'doctor001', '0b14d501a594442a01c6859541bcb3e8164d183d32937b851835442f69d5c94e');
INSERT INTO `doctor` VALUES (2, '李四', '女', '副主任医师', 1, '13800000002', 'doctor002', '6cf615d5bcaac778352a8f1f3360d23f02f34ec182e259897fd6ce485d7870d4');
INSERT INTO `doctor` VALUES (3, '王五', '男', '主治医师', 2, '13800000003', 'doctor003', '5906ac361a137e2d286465cd6588ebb5ac3f5ae955001100bc41577c3d751764');
INSERT INTO `doctor` VALUES (4, '赵六', '女', '主任医师', 3, '13800000004', 'doctor004', 'b97873a40f73abedd8d685a7cd5e5f85e4a9cfb83eac26886640a0813850122b');

-- ----------------------------
-- Table structure for drug
-- ----------------------------
DROP TABLE IF EXISTS `drug`;
CREATE TABLE `drug`  (
  `drug_id` int NOT NULL AUTO_INCREMENT,
  `drug_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `stock` int NOT NULL,
  `usage_instructions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  PRIMARY KEY (`drug_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of drug
-- ----------------------------
INSERT INTO `drug` VALUES (1, '感冒灵颗粒', 25.50, 100, '口服，一次1袋，一日3次');
INSERT INTO `drug` VALUES (2, '阿莫西林胶囊', 32.80, 200, '口服，一次2粒，一日3次');
INSERT INTO `drug` VALUES (3, '999', 6.00, 33, '想吃就吃');
INSERT INTO `drug` VALUES (4, '感冒灵', 6.00, 900, '想吃就吃');

-- ----------------------------
-- Table structure for inpatient_file
-- ----------------------------
DROP TABLE IF EXISTS `inpatient_file`;
CREATE TABLE `inpatient_file`  (
  `file_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `doc_id` int NOT NULL,
  `ward_id` int NOT NULL,
  `bed_number` int NOT NULL,
  `admit_date` datetime NOT NULL,
  `discharge_date` datetime NULL DEFAULT NULL,
  `initial_diagnosis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `deposit` decimal(10, 2) NOT NULL,
  `total_cost` decimal(10, 2) NULL DEFAULT 0.00,
  `is_active` tinyint(1) NULL DEFAULT 1,
  PRIMARY KEY (`file_id`) USING BTREE,
  UNIQUE INDEX `ward_id`(`ward_id` ASC, `bed_number` ASC) USING BTREE,
  INDEX `patient_id`(`patient_id` ASC) USING BTREE,
  INDEX `doc_id`(`doc_id` ASC) USING BTREE,
  CONSTRAINT `inpatient_file_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `inpatient_file_ibfk_2` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `inpatient_file_ibfk_3` FOREIGN KEY (`ward_id`) REFERENCES `ward` (`ward_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inpatient_file
-- ----------------------------
INSERT INTO `inpatient_file` VALUES (1, 1, 3, 1, 1, '2025-06-01 08:00:00', NULL, '肺炎', 2000.00, 0.00, 1);
INSERT INTO `inpatient_file` VALUES (2, 1, 1, 1, 2, '2025-05-25 00:00:00', NULL, '', 0.00, 0.00, 1);
INSERT INTO `inpatient_file` VALUES (3, 1, 1, 1, 3, '2025-05-25 00:00:00', NULL, '', 0.00, 0.00, 1);
INSERT INTO `inpatient_file` VALUES (4, 1, 1, 1, 4, '2025-05-26 00:00:00', NULL, '', 0.00, 0.00, 1);

-- ----------------------------
-- Table structure for inpatient_record
-- ----------------------------
DROP TABLE IF EXISTS `inpatient_record`;
CREATE TABLE `inpatient_record`  (
  `record_id` int NOT NULL AUTO_INCREMENT,
  `file_id` int NOT NULL,
  `record_date` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `symptoms` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `treatment_plan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `prescriptions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `daily_cost` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`record_id`) USING BTREE,
  INDEX `file_id`(`file_id` ASC) USING BTREE,
  CONSTRAINT `inpatient_record_ibfk_1` FOREIGN KEY (`file_id`) REFERENCES `inpatient_file` (`file_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inpatient_record
-- ----------------------------
INSERT INTO `inpatient_record` VALUES (1, 1, '2025-05-25 19:42:36', '咳嗽、发热', '静脉滴注抗生素，吸氧', '头孢曲松钠注射液', 600.00);

-- ----------------------------
-- Table structure for outpatient_schedule
-- ----------------------------
DROP TABLE IF EXISTS `outpatient_schedule`;
CREATE TABLE `outpatient_schedule`  (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `doc_id` int NOT NULL,
  `schedule_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_available` tinyint(1) NULL DEFAULT 1,
  PRIMARY KEY (`schedule_id`) USING BTREE,
  INDEX `doc_id`(`doc_id` ASC) USING BTREE,
  CONSTRAINT `outpatient_schedule_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outpatient_schedule
-- ----------------------------
INSERT INTO `outpatient_schedule` VALUES (1, 1, '2025-06-01', '09:00:00', '11:30:00', 1);
INSERT INTO `outpatient_schedule` VALUES (2, 2, '2025-06-01', '14:00:00', '16:30:00', 1);

-- ----------------------------
-- Table structure for outpatient_visit
-- ----------------------------
DROP TABLE IF EXISTS `outpatient_visit`;
CREATE TABLE `outpatient_visit`  (
  `visit_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `doc_id` int NOT NULL,
  `visit_date` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `is_initial_visit` tinyint(1) NOT NULL,
  `symptom` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `prescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `diagnosis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `fee` decimal(10, 2) NOT NULL,
  `is_paid` tinyint(1) NULL DEFAULT 0,
  PRIMARY KEY (`visit_id`) USING BTREE,
  INDEX `patient_id`(`patient_id` ASC) USING BTREE,
  INDEX `doc_id`(`doc_id` ASC) USING BTREE,
  CONSTRAINT `outpatient_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `outpatient_visit_ibfk_2` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outpatient_visit
-- ----------------------------
INSERT INTO `outpatient_visit` VALUES (1, 1, 1, '2025-05-25 19:42:36', 1, '头痛、发热', '999吃五包', '上呼吸道感染', 128.50, 1);
INSERT INTO `outpatient_visit` VALUES (2, 2, 2, '2025-05-25 19:42:36', 1, '咳嗽、喉咙痛', '阿莫西林胶囊*1盒', '急性咽炎', 85.00, 0);
INSERT INTO `outpatient_visit` VALUES (3, 1, 1, '2025-05-25 19:43:34', 1, '', '999吃五包', NULL, 0.00, 1);
INSERT INTO `outpatient_visit` VALUES (4, 1, 3, '2025-05-25 19:43:49', 1, '', NULL, NULL, 0.00, 1);
INSERT INTO `outpatient_visit` VALUES (5, 1, 1, '2025-05-26 10:01:58', 1, '', NULL, NULL, 0.00, 0);

-- ----------------------------
-- Table structure for patient
-- ----------------------------
DROP TABLE IF EXISTS `patient`;
CREATE TABLE `patient`  (
  `patient_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gender` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`patient_id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  CONSTRAINT `patient_chk_1` CHECK (`gender` in (_utf8mb4'男',_utf8mb4'女'))
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of patient
-- ----------------------------
INSERT INTO `patient` VALUES (1, '孙七', '男', '北京市朝阳区', '13900000001', 'patient001', '497b5e5c927d7a17eee52199ac1443df1fb8cb2b4923ced5255601b22c885f18');
INSERT INTO `patient` VALUES (2, '周八', '女', '上海市浦东新区', '13900000002', 'patient002', 'cd4e790a5f73201c2022ec0c326ae03e0003fb6218dcc6f270bd32dbebee42e8');

-- ----------------------------
-- Table structure for ward
-- ----------------------------
DROP TABLE IF EXISTS `ward`;
CREATE TABLE `ward`  (
  `ward_id` int NOT NULL AUTO_INCREMENT,
  `dept_id` int NOT NULL,
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price_per_day` decimal(10, 2) NOT NULL,
  `total_beds` int NOT NULL,
  `available_beds` int NOT NULL,
  PRIMARY KEY (`ward_id`) USING BTREE,
  INDEX `dept_id`(`dept_id` ASC) USING BTREE,
  CONSTRAINT `ward_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ward
-- ----------------------------
INSERT INTO `ward` VALUES (1, 3, '住院楼2层A区', 150.00, 10, 7);
INSERT INTO `ward` VALUES (2, 4, '住院楼3层B区', 200.00, 8, 8);

SET FOREIGN_KEY_CHECKS = 1;
