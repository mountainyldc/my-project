import tkinter as tk
import db
from tkinter import simpledialog, messagebox


class PatientUI(tk.Tk):
    def __init__(self, patient):
        super().__init__()
        self.title("病人界面")
        self.geometry("1200x900")
        self.patient_id = patient[0]
        tk.Label(self, text=f"欢迎您，{patient[1]}", font=("Arial", 14)).pack(pady=10)

        self.create_buttons()

    def create_buttons(self):
        """集中创建按钮，使代码结构更清晰"""
        button_texts = ["查看就诊记录", "查看费用明细", "挂号", "缴费", "办理住院", "查看住院记录"]
        button_commands = [self.view_visits, self.view_fees, self.register, self.pay_fee, self.hospitalize, self.view_hospitalization_records]
        for text, command in zip(button_texts, button_commands):
            tk.Button(self, text=text, command=command).pack(fill="x", padx=20, pady=5)

    def view_visits(self):
        """查看就诊记录"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT visit_date, diagnosis FROM outpatient_visit WHERE patient_id=%s", (self.patient_id,))
            visits = cursor.fetchall()
            visit_text = "\n".join([f"{v[0]} - {v[1]}" for v in visits])
            messagebox.showinfo("就诊记录", visit_text or "暂无记录")
        except Exception as e:
            messagebox.showerror("错误", f"获取就诊记录失败：{str(e)}")
        finally:
            conn.close()

    def view_fees(self):
        """查看费用明细"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT fee, is_paid FROM outpatient_visit WHERE patient_id=%s", (self.patient_id,))
            fees = cursor.fetchall()
            fee_text = "\n".join([f"¥{f[0]} - {'已缴费' if f[1] else '未缴费'}" for f in fees])
            messagebox.showinfo("费用明细", fee_text or "暂无记录")
        except Exception as e:
            messagebox.showerror("错误", f"获取费用明细失败：{str(e)}")
        finally:
            conn.close()

    def register(self):
        """挂号功能"""
        doc_id = simpledialog.askinteger("挂号", "请输入医生 ID")
        if doc_id:
            conn = db.connect()
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO outpatient_visit (patient_id, doc_id, is_initial_visit, symptom, fee) VALUES (%s, %s, true, '', 0)", (self.patient_id, doc_id))
                conn.commit()
                messagebox.showinfo("成功", "挂号成功！")
            except Exception as e:
                conn.rollback()
                if "duplicate" in str(e).lower():  # 假设报错包含duplicate是重复挂号问题
                    messagebox.showerror("错误", "您可能已挂过该医生的号，请勿重复挂号！")
                else:
                    messagebox.showerror("错误", f"挂号失败：{str(e)}")
            finally:
                conn.close()

    def pay_fee(self):
        """缴费功能"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("UPDATE outpatient_visit SET is_paid = true WHERE patient_id = %s AND is_paid = false", (self.patient_id,))
            if cursor.rowcount == 0:  # 若未更新任何行，提示无未缴费记录
                messagebox.showinfo("提示", "您当前没有未缴费记录。")
            else:
                conn.commit()
                messagebox.showinfo("成功", "缴费成功！")
        except Exception as e:
            conn.rollback()
            messagebox.showerror("错误", f"缴费失败：{str(e)}")
        finally:
            conn.close()

    def hospitalize(self):
        """办理住院功能"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            # 检查是否有可用病床，从ward表获取
            cursor.execute("SELECT ward_id, available_beds FROM ward WHERE available_beds > 0 LIMIT 1")
            available_ward = cursor.fetchone()
            if not available_ward:
                messagebox.showerror("错误", "暂无可用病床，无法办理住院。")
                return
            ward_id, available_beds = available_ward
            # 查找下一个可用床位号，假设床位号从1开始连续编号
            cursor.execute(f"SELECT bed_number FROM inpatient_file WHERE ward_id = {ward_id} ORDER BY bed_number DESC LIMIT 1")
            last_bed_number = cursor.fetchone()
            bed_number = 1 if not last_bed_number else last_bed_number[0] + 1
            # 插入住院档案记录
            cursor.execute("INSERT INTO inpatient_file (patient_id, doc_id, ward_id, bed_number, admit_date, initial_diagnosis, deposit) "
                           "VALUES (%s, %s, %s, %s, CURDATE(), '', 0)",
                           (self.patient_id, 1, ward_id, bed_number))  # 这里doc_id暂时写1，实际应根据逻辑获取
            # 更新病房可用床位数
            cursor.execute("UPDATE ward SET available_beds = available_beds - 1 WHERE ward_id = %s", (ward_id,))
            conn.commit()
            messagebox.showinfo("成功", "办理住院成功！")
        except Exception as e:
            conn.rollback()
            messagebox.showerror("错误", f"办理住院失败：{str(e)}")
        finally:
            conn.close()

    def view_hospitalization_records(self):
        """查看住院记录"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT admit_date, discharge_date, ward_id, bed_number, initial_diagnosis "
                           "FROM inpatient_file WHERE patient_id = %s", (self.patient_id,))
            records = cursor.fetchall()
            record_text = "\n".join([f"入院时间: {r[0]}, 出院时间: {r[1] if r[1] else '未出院'}, 病房编号: {r[2]}, 床位号: {r[3]}, 初步诊断: {r[4]}" for r in records])
            messagebox.showinfo("住院记录", record_text or "暂无住院记录")
        except Exception as e:
            messagebox.showerror("错误", f"获取住院记录失败：{str(e)}")
        finally:
            conn.close()