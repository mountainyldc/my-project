import tkinter as tk
import db
from tkinter import simpledialog, messagebox


class DoctorUI(tk.Tk):
    def __init__(self, doctor):
        super().__init__()
        self.title("医生界面")
        self.geometry("1200x900")
        self.doc_id = doctor[0]
        tk.Label(self, text=f"欢迎您，{doctor[1]}（{doctor[3]}）", font=("Arial", 14)).pack(pady=10)

        tk.Button(self, text="查看排班", command=self.view_schedule).pack(fill="x", padx=20, pady=5)
        tk.Button(self, text="查看接诊记录", command=self.view_visits).pack(fill="x", padx=20, pady=5)
        tk.Button(self, text="开具处方", command=self.write_prescription).pack(fill="x", padx=20, pady=5)
        tk.Button(self, text="查看住院病人", command=self.view_hospitalized_patients).pack(fill="x", padx=20, pady=5)
        tk.Button(self, text="开具住院诊疗方案", command=self.write_hospitalization_plan).pack(fill="x", padx=20, pady=5)

    def view_schedule(self):
        """查看排班"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT schedule_date, start_time, end_time FROM outpatient_schedule WHERE doc_id = %s", (self.doc_id,))
            schedules = cursor.fetchall()
            schedule_text = "\n".join([f"{s[0]} {s[1]} - {s[2]}" for s in schedules])
            tk.messagebox.showinfo("排班情况", schedule_text or "暂无排班")
        except Exception as e:
            tk.messagebox.showerror("错误", f"获取排班信息失败：{str(e)}")
        finally:
            conn.close()

    def view_visits(self):
        """查看接诊记录"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT visit_date, symptom, diagnosis FROM outpatient_visit WHERE doc_id = %s", (self.doc_id,))
            visits = cursor.fetchall()
            visit_text = "\n".join([f"{v[0]} - {v[1]} - {v[2]}" for v in visits])
            tk.messagebox.showinfo("接诊记录", visit_text or "暂无接诊")
        except Exception as e:
            tk.messagebox.showerror("错误", f"获取接诊记录失败：{str(e)}")
        finally:
            conn.close()

    def write_prescription(self):
        """开具处方"""
        patient_id = simpledialog.askinteger("开具处方", "请输入患者 ID")
        if patient_id:
            prescription = simpledialog.askstring("开具处方", "请输入处方内容")
            if prescription:
                conn = db.connect()
                cursor = conn.cursor()
                try:
                    cursor.execute("UPDATE outpatient_visit SET prescription = %s WHERE patient_id = %s AND doc_id = %s", (prescription, patient_id, self.doc_id))
                    conn.commit()
                    tk.messagebox.showinfo("成功", "处方开具成功！")
                except Exception as e:
                    conn.rollback()
                    tk.messagebox.showerror("错误", f"开具处方失败：{str(e)}")
                finally:
                    conn.close()

    def view_hospitalized_patients(self):
        """查看住院病人"""
        conn = db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT patient.patient_id, patient.name, inpatient_file.admit_date, inpatient_file.ward_id, inpatient_file.bed_number "
                           "FROM patient "
                           "JOIN inpatient_file ON patient.patient_id = inpatient_file.patient_id "
                           "WHERE inpatient_file.doc_id = %s AND inpatient_file.discharge_date IS NULL", (self.doc_id,))
            patients = cursor.fetchall()
            patient_text = "\n".join([f"患者 ID: {p[0]}, 姓名: {p[1]}, 入院时间: {p[2]}, 病房编号: {p[3]}, 床位号: {p[4]}" for p in patients])
            tk.messagebox.showinfo("住院病人", patient_text or "暂无住院病人")
        except Exception as e:
            tk.messagebox.showerror("错误", f"获取住院病人信息失败：{str(e)}")
        finally:
            conn.close()

    def write_hospitalization_plan(self):
        """开具住院诊疗方案"""
        patient_id = simpledialog.askinteger("开具住院诊疗方案", "请输入患者 ID")
        if patient_id:
            plan = simpledialog.askstring("开具住院诊疗方案", "请输入诊疗方案内容")
            if plan:
                conn = db.connect()
                cursor = conn.cursor()
                try:
                    # 查找患者的住院档案file_id
                    cursor.execute("SELECT file_id FROM inpatient_file WHERE patient_id = %s AND discharge_date IS NULL", (patient_id,))
                    file_id = cursor.fetchone()
                    if not file_id:
                        tk.messagebox.showerror("错误", "该患者未住院或已出院。")
                        return
                    file_id = file_id[0]
                    # 插入住院记录
                    cursor.execute("INSERT INTO inpatient_record (file_id, record_date, symptoms, treatment_plan, prescriptions, daily_cost) "
                                   "VALUES (%s, CURDATE(), '', %s, '', 0)", (file_id, plan))
                    conn.commit()
                    tk.messagebox.showinfo("成功", "住院诊疗方案开具成功！")
                except Exception as e:
                    conn.rollback()
                    tk.messagebox.showerror("错误", f"开具住院诊疗方案失败：{str(e)}")
                finally:
                    conn.close()