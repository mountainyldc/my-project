import mysql.connector

def connect():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456",
        database="hospital_db",
        autocommit=True
    )

# 调用 connect() 函数获取连接对象
connection = connect()
