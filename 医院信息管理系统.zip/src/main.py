# main.py
import tkinter as tk
from tkinter import messagebox
from admin_ui import AdminUI
from doctor_ui import DoctorUI
from patient_ui import PatientUI
import db

def login():
    username = username_entry.get()
    password = password_entry.get()
    user_type = user_type_var.get()

    conn = db.connect()
    cursor = conn.cursor()

    if user_type == "admin":
        cursor.execute("SELECT * FROM administrator WHERE username=%s AND password_hash=SHA2(%s, 256)", (username, password))
        user = cursor.fetchone()
        if user:
            root.destroy()
            AdminUI(user).mainloop()
            return
    elif user_type == "doctor":
        cursor.execute("SELECT * FROM doctor WHERE username=%s AND password_hash=SHA2(%s, 256)", (username, password))
        user = cursor.fetchone()
        if user:
            root.destroy()
            DoctorUI(user).mainloop()
            return
    elif user_type == "patient":
        cursor.execute("SELECT * FROM patient WHERE username=%s AND password_hash=SHA2(%s, 256)", (username, password))
        user = cursor.fetchone()
        if user:
            root.destroy()
            PatientUI(user).mainloop()
            return

    messagebox.showerror("登录失败", "用户名或密码错误")
    conn.close()

# 创建窗口
root = tk.Tk()
root.title("医院管理系统 - 登录")
root.geometry("400x300")  # 设置窗口大小为 400x300

# 登录标签
tk.Label(root, text="欢迎登录医院管理系统", font=("Arial", 16)).pack(pady=20)

# 用户类型选择
frame0 = tk.Frame(root)
frame0.pack(pady=5)
tk.Label(frame0, text="用户类型：", font=("Arial", 12), width=10, anchor="e").pack(side=tk.LEFT)
user_type_var = tk.StringVar(value="admin")
tk.Radiobutton(frame0, text="管理员", variable=user_type_var, value="admin", font=("Arial", 12)).pack(side=tk.LEFT)
tk.Radiobutton(frame0, text="医生", variable=user_type_var, value="doctor", font=("Arial", 12)).pack(side=tk.LEFT)
tk.Radiobutton(frame0, text="患者", variable=user_type_var, value="patient", font=("Arial", 12)).pack(side=tk.LEFT)

# 用户名
frame1 = tk.Frame(root)
frame1.pack(pady=5)
tk.Label(frame1, text="用户名：", font=("Arial", 12), width=10, anchor="e").pack(side=tk.LEFT)
username_entry = tk.Entry(frame1, font=("Arial", 12))
username_entry.pack(side=tk.LEFT)

# 密码
frame2 = tk.Frame(root)
frame2.pack(pady=5)
tk.Label(frame2, text="密码：", font=("Arial", 12), width=10, anchor="e").pack(side=tk.LEFT)
password_entry = tk.Entry(frame2, show="*", font=("Arial", 12))
password_entry.pack(side=tk.LEFT)

# 登录按钮
tk.Button(root, text="登录", font=("Arial", 12), width=15, command=login).pack(pady=20)

root.mainloop()