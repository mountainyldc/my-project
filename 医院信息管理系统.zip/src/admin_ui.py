import tkinter as tk
from tkinter import ttk, messagebox
import db


class AdminUI(tk.Tk):
    def __init__(self, admin):
        super().__init__()
        self.title("医院信息管理系统 - 管理员界面")
        self.geometry("1000x600")
        self.configure(bg="#f0f0f0")

        # 存储当前选择的表和ID
        self.current_table = None
        self.selected_id = None

        # 创建顶部导航栏
        self.create_navigation_bar(admin)

        # 创建主框架
        self.main_frame = tk.Frame(self, bg="#f0f0f0")
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # 创建操作按钮框架
        self.create_action_buttons()

        # 创建数据表格
        self.create_data_table()

        # 创建详情表单
        self.create_detail_form()

    def create_navigation_bar(self, admin):
        nav_frame = tk.Frame(self, bg="#333", height=40)
        nav_frame.pack(fill=tk.X)

        tk.Label(nav_frame, text=f"欢迎您，{admin[3]}", bg="#333", fg="white").pack(side=tk.LEFT, padx=10, pady=10)

        tk.Button(nav_frame, text="科室管理", command=lambda: self.load_table("department"),
                  bg="#4CAF50", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=5, pady=5)

        tk.Button(nav_frame, text="医生管理", command=lambda: self.load_table("doctor"),
                  bg="#2196F3", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=5, pady=5)

        tk.Button(nav_frame, text="药品管理", command=lambda: self.load_table("drug"),
                  bg="#FF9800", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=5, pady=5)

        tk.Button(nav_frame, text="用户管理", command=lambda: self.load_table("patient"),
                  bg="#9C27B0", fg="white", relief=tk.FLAT).pack(side=tk.LEFT, padx=5, pady=5)

        tk.Button(nav_frame, text="退出系统", command=self.destroy,
                  bg="#f44336", fg="white", relief=tk.FLAT).pack(side=tk.RIGHT, padx=10, pady=5)

    def create_action_buttons(self):
        btn_frame = tk.Frame(self.main_frame, bg="#f0f0f0")
        btn_frame.pack(fill=tk.X, pady=10)

        self.search_entry = tk.Entry(btn_frame, width=30)
        self.search_entry.pack(side=tk.LEFT, padx=5)

        self.search_btn = tk.Button(btn_frame, text="搜索", command=self.search_data,
                                    bg="#4CAF50", fg="white", relief=tk.FLAT)
        self.search_btn.pack(side=tk.LEFT, padx=5)

        self.refresh_btn = tk.Button(btn_frame, text="刷新", command=self.refresh_data,
                                     bg="#2196F3", fg="white", relief=tk.FLAT)
        self.refresh_btn.pack(side=tk.LEFT, padx=5)

        self.add_btn = tk.Button(btn_frame, text="新增", command=self.add_data,
                                 bg="#4CAF50", fg="white", relief=tk.FLAT)
        self.add_btn.pack(side=tk.LEFT, padx=5)

        self.update_btn = tk.Button(btn_frame, text="修改", command=self.update_data,
                                    bg="#FF9800", fg="white", relief=tk.FLAT)
        self.update_btn.pack(side=tk.LEFT, padx=5)

        self.delete_btn = tk.Button(btn_frame, text="删除", command=self.delete_data,
                                    bg="#f44336", fg="white", relief=tk.FLAT)
        self.delete_btn.pack(side=tk.LEFT, padx=5)

    def create_data_table(self):
        table_frame = tk.Frame(self.main_frame, bg="#f0f0f0")
        table_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.data_table = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        self.data_table.pack(fill=tk.BOTH, expand=True)

        scrollbar.config(command=self.data_table.yview)
        self.data_table.bind("<<TreeviewSelect>>", self.on_select)

    def create_detail_form(self):
        # 将form_frame定义为实例属性
        self.form_frame = tk.LabelFrame(self.main_frame, text="详情信息", bg="#f0f0f0")
        self.form_frame.pack(fill=tk.X, pady=10)

        self.form_entries = {}

    def load_table(self, table_name):
        self.current_table = table_name
        self.selected_id = None

        conn = db.connect()
        cursor = conn.cursor()

        # 获取列名
        cursor.execute(f"SHOW COLUMNS FROM {table_name}")
        columns = cursor.fetchall()
        self.column_names = [col[0] for col in columns]

        # 获取数据
        cursor.execute(f"SELECT * FROM {table_name}")
        data = cursor.fetchall()
        conn.close()

        # 清空表格
        for item in self.data_table.get_children():
            self.data_table.delete(item)

        # 设置表格列
        self.data_table["columns"] = self.column_names
        self.data_table["show"] = "headings"

        for col in self.column_names:
            self.data_table.heading(col, text=col)
            self.data_table.column(col, width=100, anchor=tk.CENTER)

        # 填充数据
        for row in data:
            self.data_table.insert("", tk.END, values=row)

        # 更新表单字段
        self.update_form_fields()

    def update_form_fields(self):
        # 清空现有表单
        for widget in self.form_frame.winfo_children():
            widget.destroy()

        # 重新创建表单字段
        self.form_entries = {}
        row = 0

        for col in self.column_names:
            # 跳过ID字段（不允许修改）
            if col.endswith("_id") and self.selected_id is not None:
                continue

            tk.Label(self.form_frame, text=f"{col}:", bg="#f0f0f0").grid(row=row, column=0, sticky=tk.W, padx=10,
                                                                         pady=5)

            entry = tk.Entry(self.form_frame, width=30)
            entry.grid(row=row, column=1, padx=10, pady=5)
            self.form_entries[col] = entry
            row += 1

    def on_select(self, event):
        if not self.data_table.selection():
            return

        self.selected_id = self.data_table.item(self.data_table.selection()[0])["values"][0]

        # 填充表单数据
        conn = db.connect()
        cursor = conn.cursor()
        if self.current_table == "department":
            cursor.execute(f"SELECT * FROM {self.current_table} WHERE dept_id = %s", (self.selected_id,))
        elif self.current_table == "doctor":
            cursor.execute(f"SELECT * FROM {self.current_table} WHERE doc_id = %s", (self.selected_id,))
        elif self.current_table == "drug":
            cursor.execute(f"SELECT * FROM {self.current_table} WHERE drug_id = %s", (self.selected_id,))
        elif self.current_table == "patient":
            cursor.execute(f"SELECT * FROM {self.current_table} WHERE patient_id = %s", (self.selected_id,))
        data = cursor.fetchone()
        conn.close()

        if data:
            for i, col in enumerate(self.column_names):
                if col in self.form_entries:
                    self.form_entries[col].delete(0, tk.END)
                    self.form_entries[col].insert(0, data[i])

    def search_data(self):
        if not self.current_table:
            return

        keyword = self.search_entry.get().strip()
        if not keyword:
            self.refresh_data()
            return

        conn = db.connect()
        cursor = conn.cursor()

        # 构建搜索条件
        conditions = " OR ".join([f"{col} LIKE %s" for col in self.column_names])
        query = f"SELECT * FROM {self.current_table} WHERE {conditions}"
        params = tuple([f"%{keyword}%" for _ in self.column_names])

        cursor.execute(query, params)
        data = cursor.fetchall()
        conn.close()

        # 清空表格并填充搜索结果
        for item in self.data_table.get_children():
            self.data_table.delete(item)

        for row in data:
            self.data_table.insert("", tk.END, values=row)

    def refresh_data(self):
        if self.current_table:
            self.load_table(self.current_table)

    def add_data(self):
        if not self.current_table:
            return
        add_window = tk.Toplevel(self)
        add_window.title(f"新增{self.current_table}数据")
        entry_widgets = {}
        conn = db.connect()
        cursor = conn.cursor()
        cursor.execute(f"SHOW COLUMNS FROM {self.current_table}")
        columns = cursor.fetchall()
        for i, col in enumerate(columns):
            col_name = col[0]
            tk.Label(add_window, text=f"{col_name}:").grid(row=i, column=0, padx=5, pady=5)
            entry = tk.Entry(add_window)
            entry.grid(row=i, column=1, padx=5, pady=5)
            entry_widgets[col_name] = entry
        confirm_btn = tk.Button(add_window, text="确认新增",
                                command=lambda: self.confirm_add_data(entry_widgets, conn, cursor))
        confirm_btn.grid(row=len(columns), column=0, columnspan=2, padx=5, pady=5)

    def confirm_add_data(self, entry_widgets, conn, cursor):
        data = {}
        for col, entry in entry_widgets.items():
            data[col] = entry.get().strip()
        # 验证必填字段
        for col in data.keys():
            if not data[col]:
                messagebox.showerror("错误", f"{col}字段不能为空，请重新输入！")
                return
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        values = tuple(data.values())
        try:
            cursor.execute(f"INSERT INTO {self.current_table} ({columns}) VALUES ({placeholders})", values)
            conn.commit()
            messagebox.showinfo("成功", "数据添加成功！")
            self.refresh_data()
            conn.close()
            entry_widgets[col].master.destroy()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("错误", f"添加数据失败：{str(e)}")
            conn.close()

    def update_data(self):
        if not self.current_table or self.selected_id is None:
            messagebox.showerror("错误", "请先选择要修改的数据！")
            return
        conn = db.connect()
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM {self.current_table} WHERE {self.current_table[:3]}_id = %s",
                       (self.selected_id,))
        data = cursor.fetchone()
        if data:
            update_window = tk.Toplevel(self)
            update_window.title(f"修改{self.current_table}数据")
            entry_widgets = {}
            column_names = [desc[0] for desc in cursor.description]
            for i, col in enumerate(column_names):
                tk.Label(update_window, text=f"{col}:").grid(row=i, column=0, padx=5, pady=5)
                entry = tk.Entry(update_window)
                entry.insert(0, data[i])
                entry.grid(row=i, column=1, padx=5, pady=5)
                entry_widgets[col] = entry
            confirm_btn = tk.Button(update_window, text="确认修改",
                                    command=lambda: self.confirm_update_data(entry_widgets, conn, cursor))
            confirm_btn.grid(row=len(column_names), column=0, columnspan=2, padx=5, pady=5)

    def confirm_update_data(self, entry_widgets, conn, cursor):
        data = {}
        for col, entry in entry_widgets.items():
            data[col] = entry.get().strip()
        # 验证必填字段
        for col in data.keys():
            if not data[col]:
                messagebox.showerror("错误", f"{col}字段不能为空，请重新输入！")
                return
        set_clause = ", ".join([f"{col} = %s" for col in data.keys()])
        values = tuple(data.values()) + (self.selected_id,)
        try:
            cursor.execute(f"UPDATE {self.current_table} SET {set_clause} WHERE {self.current_table[:3]}_id = %s",
                           values)
            conn.commit()
            messagebox.showinfo("成功", "数据修改成功！")
            self.refresh_data()
            conn.close()
            entry_widgets[col].master.destroy()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("错误", f"修改数据失败：{str(e)}")
            conn.close()

    def delete_data(self):
        if not self.current_table or self.selected_id is None:
            messagebox.showerror("错误", "请先选择要删除的数据！")
            return

        if messagebox.askyesno("确认", "确定要删除这条数据吗？"):
            conn = db.connect()
            cursor = conn.cursor()

            if self.current_table == "department":
                cursor.execute(f"DELETE FROM {self.current_table} WHERE dept_id = %s", (self.selected_id,))
            elif self.current_table == "doctor":
                cursor.execute(f"DELETE FROM {self.current_table} WHERE doc_id = %s", (self.selected_id,))
            elif self.current_table == "drug":
                cursor.execute(f"DELETE FROM {self.current_table} WHERE drug_id = %s", (self.selected_id,))
            elif self.current_table == "patient":
                cursor.execute(f"DELETE FROM {self.current_table} WHERE patient_id = %s", (self.selected_id,))

            try:
                conn.commit()
                messagebox.showinfo("成功", "数据删除成功！")
                self.refresh_data()
                self.selected_id = None
            except Exception as e:
                conn.rollback()
                messagebox.showerror("错误", f"删除数据失败：{str(e)}")
            finally:
                conn.close()