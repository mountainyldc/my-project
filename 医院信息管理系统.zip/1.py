import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from mysql.connector import Error

# 数据库连接配置
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '123456',
    'database': 'hospital_db'
}


def connect_to_db():
    """创建数据库连接"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Error as e:
        messagebox.showerror("数据库错误", f"连接失败: {str(e)}")
    return None


class HospitalSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("医院管理系统")
        self.root.geometry("1200x800")

        # 登录状态管理
        self.current_user = None
        self.current_role = None

        # 初始化界面
        self.show_login()

    def show_login(self):
        """登录界面"""
        # 清空现有组件
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = ttk.Frame(self.root, padding=20)
        frame.pack(expand=True)

        ttk.Label(frame, text="医院管理系统登录", font=('Arial', 18, 'bold')).grid(row=0, column=0, columnspan=2,
                                                                                   pady=10)

        ttk.Label(frame, text="用户名:").grid(row=1, column=0, pady=5, sticky='w')
        self.username_entry = ttk.Entry(frame)
        self.username_entry.grid(row=1, column=1, pady=5)

        ttk.Label(frame, text="密码:").grid(row=2, column=0, pady=5, sticky='w')
        self.password_entry = ttk.Entry(frame, show="*")
        self.password_entry.grid(row=2, column=1, pady=5)

        ttk.Button(frame, text="登录", command=self.verify_login).grid(row=3, column=0, columnspan=2, pady=10)
        ttk.Button(frame, text="退出", command=self.root.destroy).grid(row=4, column=0, columnspan=2)

    def verify_login(self):
        """验证登录信息"""
        username = self.username_entry.get()
        password_hash = self.password_entry.get()

        conn = connect_to_db()
        if not conn:
            return

        try:
            cursor = conn.cursor()
            # 检查管理员
            cursor.execute("""
                SELECT admin_id, role FROM administrator
                WHERE username = %s AND password_hash = SHA2(%s, 256)
            """, (username, password_hash))
            admin = cursor.fetchone()

            if admin:
                self.current_user = admin[0]
                self.current_role = admin[1]
                self.show_admin_dashboard()
                return

            # 检查医生
            cursor.execute("""
                SELECT doc_id, dept_id FROM doctor
                WHERE username = %s AND password_hash = SHA2(%s, 256)
            """, (username, password_hash))
            doctor = cursor.fetchone()

            if doctor:
                self.current_user = doctor[0]
                self.current_role = "医生"
                self.show_doctor_dashboard(doctor[1])
                return

            # 检查患者
            cursor.execute("""
                SELECT patient_id FROM patient
                WHERE username = %s AND password_hash = SHA2(%s, 256)
            """, (username, password_hash))
            patient = cursor.fetchone()

            if patient:
                self.current_user = patient[0]
                self.current_role = "患者"
                self.show_patient_dashboard()
                return

            messagebox.showerror("登录失败", "用户名或密码错误")

        except Error as e:
            messagebox.showerror("数据库错误", f"操作失败: {str(e)}")
        finally:
            conn.close()

    # --------------------- 管理员功能 ---------------------
    def show_admin_dashboard(self):
        """管理员主界面"""
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = ttk.Frame(self.root, padding=20)
        frame.pack(expand=True, fill='both')

        ttk.Label(frame, text="管理员面板", font=('Arial', 16, 'bold')).pack(pady=10)

        # 功能按钮
        ttk.Button(frame, text="科室管理", command=self.manage_departments).pack(pady=5, fill='x')
        ttk.Button(frame, text="医生管理", command=self.manage_doctors).pack(pady=5, fill='x')
        ttk.Button(frame, text="药品管理", command=self.manage_drugs).pack(pady=5, fill='x')
        ttk.Button(frame, text="统计报表", command=self.show_statistics).pack(pady=5, fill='x')
        ttk.Button(frame, text="退出登录", command=self.show_login).pack(pady=10, fill='x')

    def manage_departments(self):
        """科室管理界面"""
        # 实现添加、删除、修改科室功能（代码省略，需补充树状图和表单组件）
        pass

    # --------------------- 医生功能 ---------------------
    def show_doctor_dashboard(self, dept_id):
        """医生主界面"""
        # 实现排班查看、接诊、开处方功能（代码省略，需补充日程表和患者列表）
        pass

    # --------------------- 患者功能 ---------------------
    def show_patient_dashboard(self):
        """患者主界面"""
        # 实现挂号、缴费、查询记录功能（代码省略，需补充操作按钮和历史记录列表）
        pass

    # --------------------- 统计功能 ---------------------
    def show_statistics(self):
        """统计报表界面"""
        # 实现科室排班、医生工作量、患者治疗情况统计（代码省略，需补充图表组件）
        pass


if __name__ == "__main__":
    root = tk.Tk()
    app = HospitalSystem(root)
    root.mainloop()